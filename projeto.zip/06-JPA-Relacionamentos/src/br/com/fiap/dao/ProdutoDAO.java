package br.com.fiap.dao;

import br.com.fiap.entity.Produto;

public interface ProdutoDAO extends GenericDAO<Produto, Integer>{

}
