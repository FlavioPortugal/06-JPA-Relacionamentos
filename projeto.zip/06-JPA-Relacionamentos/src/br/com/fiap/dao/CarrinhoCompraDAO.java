package br.com.fiap.dao;

import br.com.fiap.entity.CarrinhoCompras;

public interface CarrinhoCompraDAO 
				extends GenericDAO<CarrinhoCompras, Integer> {

}


