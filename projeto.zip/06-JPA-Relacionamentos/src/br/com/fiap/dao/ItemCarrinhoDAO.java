package br.com.fiap.dao;

import br.com.fiap.entity.ItemCarrinho;

public interface ItemCarrinhoDAO extends GenericDAO<ItemCarrinho, Integer>{

}
